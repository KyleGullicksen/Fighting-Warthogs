This code is to recreate the extension created in this tutorial: https://developer.chrome.com/extensions/getstarted
NOTE: The extension will have color if on a "https://developer.chrome.com" page 

The user is able to change the background color of the page if the extension is clicked upon and the colored button is clicked. If you click on the extension's 'Details' and find 'Extension
options' you will be redirected to a html page where you can change the color of the button

TO DOWNLOAD: Unzip and place folder in preferred directory then access your extensions on chrome (... -> More Tools -> Extensions)
	     Turn on Developer mode on the top-right
	     Load unpacked -> choose Extension directory (Titled "Extensions" and found in the directory you unzipped it in)

